// Admin JS for OpenAI Assistant v2.9.19
jQuery(()=>console.log('OA Admin loaded v2.9.19'));